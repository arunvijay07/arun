"use strict";

(function global() {// console.log('JS');
})();